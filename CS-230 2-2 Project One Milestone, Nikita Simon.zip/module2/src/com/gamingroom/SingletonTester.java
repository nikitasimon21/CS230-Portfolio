package com.gamingroom;

/**
 * A class to test singleton behavior
 *
 * @author coce@snhu.edu
 */
public class SingletonTester {

    public void testSingleton() {

        System.out.println("\nAbout to test the singleton...");

        // Obtain the same singleton instance
        GameService service = GameService.getInstance();

        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}
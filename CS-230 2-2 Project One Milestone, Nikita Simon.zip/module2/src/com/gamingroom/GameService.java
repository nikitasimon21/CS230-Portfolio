package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 *
 * @author coce@snhu.edu
 */
public class GameService {

    /**
     * A list of the active games
     */
    private static List<Game> games = new ArrayList<Game>();

    /**
     * Holds the next game identifier
     */
    private static long nextGameId = 1;

    /*
     * Singleton Pattern
     *
     * This class implements the Singleton pattern to ensure only one
     * GameService instance exists during the application's lifetime.
     * All classes access the same shared GameService through
     * getInstance(), preventing duplicate service objects.
     */
    private static GameService instance = new GameService();

    /**
     * Private constructor prevents outside classes from creating
     * additional GameService objects.
     */
    private GameService() {
    }

    /**
     * Returns the singleton GameService instance.
     *
     * @return singleton GameService object
     */
    public static GameService getInstance() {
        return instance;
    }

    /**
     * Construct a new game instance
     *
     * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {

        Game game = null;

        /*
         * Iterator Pattern
         *
         * The Iterator pattern allows each Game object stored in the
         * collection to be examined without exposing the internal
         * implementation of the list. It is used here to verify that
         * duplicate game names are not created.
         */
        Iterator<Game> iterator = games.iterator();

        while (iterator.hasNext()) {

            Game existingGame = iterator.next();

            if (existingGame.getName().equals(name)) {
                game = existingGame;
                break;
            }
        }

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

    /**
     * Returns the game instance at the specified index.
     *
     * @param index index position in the list
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     *
     * @param id unique identifier
     * @return requested game instance
     */
    public Game getGame(long id) {

        Game game = null;

        Iterator<Game> iterator = games.iterator();

        while (iterator.hasNext()) {

            Game existingGame = iterator.next();

            if (existingGame.getId() == id) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     *
     * @param name unique game name
     * @return requested game instance
     */
    public Game getGame(String name) {

        Game game = null;

        Iterator<Game> iterator = games.iterator();

        while (iterator.hasNext()) {

            Game existingGame = iterator.next();

            if (existingGame.getName().equals(name)) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns number of active games.
     *
     * @return number of games
     */
    public int getGameCount() {
        return games.size();
    }
}